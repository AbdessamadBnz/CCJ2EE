package UseCase1.example.UseCase1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UseCase1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
